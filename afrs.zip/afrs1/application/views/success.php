<!DOCTYPE html>
<html>
<head>
	<title>success</title>
</head>
<body>
	<h1>Payment success</h1>
	<a href="<?php echo base_url()?>main/report">Ticket issue</a>
</body>
</html>